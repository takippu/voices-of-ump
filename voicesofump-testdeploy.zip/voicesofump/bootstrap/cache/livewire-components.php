<?php return array (
  'guest-navigate' => 'App\\Http\\Livewire\\GuestNavigate',
);