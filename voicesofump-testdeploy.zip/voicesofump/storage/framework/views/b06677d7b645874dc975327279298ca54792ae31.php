
    <article class="p-2 ml-10 mb-2 text-base bg-white border-t border-gray-200 ">
       
        <p class="text-gray-500 dark:text-gray-400">There is no reply.</p>
    
    
    </article>
<?php /**PATH C:\Users\Hp\Documents\GitHub\voices-of-ump\voicesofump\resources\views/includes/noreplyComponent.blade.php ENDPATH**/ ?>