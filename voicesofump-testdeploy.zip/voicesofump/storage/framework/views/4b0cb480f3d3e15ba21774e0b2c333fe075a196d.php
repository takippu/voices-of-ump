<?php if(auth()->guard()->guest()): ?>
<html>
  <html lang="en">
    <head>
        <?php echo $__env->make('includes.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->make('includes.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </head>
  <body class="flex flex-col min-h-screen">
    <article class="py-12 px-4">
      <h1 class="text-4xl text-center mb-4 font-heading font-semibold"><?php echo e($confessions->title); ?></h1>
      <p class="text-center">
        <span><?php echo e($confessions->created_at->diffForHumans()); ?>, by</span>
        <a class="ml-1 text-indigo-600 hover:underline" href="#"><?php echo e(ucFirst($confessions->user->name)); ?></a>
        
      </p>
  
      <div class="max-w-3xl mx-auto mt-4 text-justify">
        <?php echo $confessions->content; ?>

      </div>
    </article>

    <?php echo $__env->make('confessions.components.commentSection', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <script src="https://code.jquery.com/jquery-3.6.1.min.js"></script>
    <script src="https://unpkg.com/flowbite@1.5.5/dist/flowbite.js"></script>
    <script src="<?php echo e(asset('/js.js')); ?> "></script>
  </body>
  <?php echo $__env->make('includes.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</html>

<?php endif; ?>

<?php if(auth()->guard()->check()): ?>
<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
  <div class="py-12">
      <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
          

          <!-- component -->
<article class="py-12 px-4 ">
  <h1 class="text-4xl text-center mb-4 font-heading font-semibold"><?php echo e($confessions->title); ?></h1>
  
  <p class="text-center">

    <span><?php echo e($confessions->created_at->diffForHumans()); ?>, by</span>
    <a class="ml-1 text-indigo-600 hover:underline" href="#"><?php echo e(ucFirst($confessions->user->name)); ?>    
      
    </a>
    <?php if(auth()->user()->id == $confessions->user_id): ?>
      
        <button onclick="window.location='/confessions/<?php echo e($confessions->id); ?>/edit'" class="bg-blue-500 hover:bg-blue-700 text-white text-xs font-bold py-2 px-2 rounded ">
            Edit Post
          </button>
         <!-- <a class="text-center" href="/confessions/<?php echo e($confessions->id); ?>/edit">[Edit]</a> -->
      
      <?php endif; ?>
  </p>
  

  <div class="max-w-3xl mx-auto mt-4 text-justify">
    <?php echo $confessions->content; ?>

  </div>
</article>

          
      </div>
      
  </div>


<?php echo $__env->make('confessions.components.commentSection', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<script src="https://code.jquery.com/jquery-3.6.1.min.js"></script>
<script src="https://unpkg.com/flowbite@1.5.5/dist/flowbite.js"></script>
<script src="<?php echo e(asset('/js.js')); ?> "></script>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php endif; ?><?php /**PATH C:\Users\Hp\Documents\GitHub\voices-of-ump\voicesofump\resources\views/confessions/show.blade.php ENDPATH**/ ?>